import NotificationTable from "../models/notification.js";

const addUserToken = async (username, token) => {
    console.log("notification.js controllers");
    const user = new NotificationTable({ username, token});
    return await user.save();
};


const getUserToken = async (username) => {
    return await NotificationTable.findOne({username});
  };

export default {addUserToken, getUserToken};