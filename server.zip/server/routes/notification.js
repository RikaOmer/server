import express from "express";
import notificationService from "../services/notification.js";
const router = express.Router();
console.log("notification.js routes");
router.route("/").post(notificationService.addUserToken).get(notificationService.getUserToken ); 

export default router;
